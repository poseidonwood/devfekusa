<?php
  //if($_POST['messages'] && is_array($_POST['messages']) && $_POST['messages'][1] == 2) echo json_encode($_POST['messages']);
  //else echo 66;
?>