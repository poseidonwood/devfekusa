<ul class="side-menu metismenu">
    <li>
        <a class="active" href="./?page=beranda"><i class="sidebar-item-icon fa fa-th-large"></i>
            <span class="nav-label">Dashboard</span>
        </a>
    </li>
    <li class="heading">FEATURES</li>
    <li>
        <a href="javascript:;"><i class="sidebar-item-icon fa fa-users"></i>
            <span class="nav-label">Pegawai</span><i class="fa fa-angle-left arrow"></i></a>
        <ul class="nav-2-level collapse">
            <li>
                <a href="./?page=pegawai">List Pegawai</a>
            </li>
        </ul>
    </li>
    <li>
        <a href="javascript:;"><i class="sidebar-item-icon fa fa-address-card"></i>
            <span class="nav-label">Penilaian</span><i class="fa fa-angle-left arrow"></i></a>
        <ul class="nav-2-level collapse">
            <li>
                <a href="./?page=tambah_penilaian">Tambah Penilaian</a>
            </li>
            
                                        <li>
                                <a href="./?page=penilaian">Penilaian</a>
                            </li>


        </ul>

    </li>
</ul>
