           <ul class="side-menu metismenu">
                    <li>
                        <a class="active" href="./?page=beranda"><i class="sidebar-item-icon fa fa-th-large"></i>
                            <span class="nav-label">Dashboard</span>
                        </a>
                    </li>
                    <li class="heading">FEATURES</li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-user"></i>
                            <span class="nav-label">User</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="./?page=tambah_user">Tambah User</a>
                            </li>
                            <li>
                                <a href="./?page=user">List User</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-briefcase"></i>
                            <span class="nav-label">Pegawai</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="./?page=tambah_pegawai">Tambah Pegawai</a>
                            </li>
                            <li>
                                <a href="./?page=pegawai">List Pegawai</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-users"></i>
                            <span class="nav-label">Bagian</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="./?page=tambah_bagian">Tambah Bagian</a>
                            </li>
                            <li>
                                <a href="./?page=bagian">List Bagian</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-table"></i>
                            <span class="nav-label">Kriteria</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                                                        <li>
                                <a href="./?page=tambah_kriteria">Tambah Kriteria</a>
                            </li>

                            <li>
                                <a href="./?page=kriteria">Kriteria</a>
                            </li>
                            
                                                                                    <li>
                                <a href="./?page=tambah_sub_kriteria">Tambah SubKriteria</a>
                            </li>

                                                        <li>
                                <a href="./?page=sub_kriteria">Sub Kriteria</a>
                            </li>

                        </ul>

                    </li>
                    <li>
                        <a href="javascript:;"><i class="sidebar-item-icon fa fa-table"></i>
                            <span class="nav-label">Bobot</span><i class="fa fa-angle-left arrow"></i></a>
                        <ul class="nav-2-level collapse">
                            <li>
                                <a href="./?page=tambah_bobot">Tambah Bobot</a>
                            </li>
                                                        <li>
                                <a href="./?page=bobot">Bobot</a>
                            </li>

                        </ul>

                    </li>
                </ul>
     