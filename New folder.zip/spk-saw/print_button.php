<div class='page-content fade-in-up'>
    <div class='ibox'>
        <div class='ibox-head'>
            <div class='ibox-title'>Cetak hasil</div>
            <div style='float:right;'>
                <a class='btn btn-primary' target="_blank" href="./cetakexcel.php">Print Excel</a>
                <a class='btn btn-primary' target="_blank" href="./cetakpdf.php">Print PDF</a>
            </div>
        </div>
    </div>
</div>